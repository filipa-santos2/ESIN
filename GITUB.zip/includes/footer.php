</main>

<footer class="footer">
  <small>© <?= date('Y') ?> Sistema de Gestão de Imunoterapia</small>
</footer>

</body>
</html>
