<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_admin();

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

$manufacturers = $pdo->query('
  SELECT "id","nome","país","email","telefone"
  FROM "Fabricantes"
  ORDER BY "id" DESC
')->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<section class="card">
  <h1>Fabricantes</h1>

  <div style="display:flex; gap:10px; align-items:center; justify-content:space-between; flex-wrap:wrap;">
    <p style="margin:0;">Lista de fabricantes (SQLite).</p>
    <a class="btn btn-primary" href="<?= $BASE_URL ?>/manufacturer_create.php">Adicionar fabricante</a>
  </div>
</section>

<section class="card">
  <?php if (empty($manufacturers)): ?>
    <p>Não existem fabricantes.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Nome</th>
          <th>País</th>
          <th>Telefone</th>
          <th>Email</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($manufacturers as $m): ?>
          <tr>
            <td><?= htmlspecialchars($m['nome']) ?></td>
            <td><?= htmlspecialchars((string)($m['país'] ?? '—')) ?></td>
            <td><?= htmlspecialchars((string)($m['telefone'] ?? '—')) ?></td>
            <td><?= htmlspecialchars((string)($m['email'] ?? '—')) ?></td>
            <td>
              <div class="actions">
                <a class="btn btn-soft" href="<?= $BASE_URL ?>/manufacturer_edit.php?id=<?= urlencode((string)$m['id']) ?>">Editar</a>
                <a class="btn btn-danger" href="<?= $BASE_URL ?>/manufacturer_delete.php?id=<?= urlencode((string)$m['id']) ?>">Apagar</a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
