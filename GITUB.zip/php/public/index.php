<?php require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/header.php'; ?>

<section class="card">
  <h1>Início</h1>
  <p>Bem-vindo ao Sistema de Gestão de Imunoterapia.</p>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
